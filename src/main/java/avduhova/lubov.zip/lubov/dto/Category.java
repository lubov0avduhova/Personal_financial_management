package avduhova.lubov.dto;

public enum Category {
    FOOD("еда"),
    CLOTHES("одежда"),
    ELECTRONICS("электроника"),
    ;


    Category(String categoryName) {

    }
}
